# coding=utf8
# from klpt.preprocess import Preprocess
# import KNN_Preprocessing
# from klpt.stem import Stem
# import klpt
# from hunspell import Hunspell
# huns = Hunspell("ckb-Arab", hunspell_data_dir=klpt.get_data("data/"))
# preprocessor_ckb = Preprocess("Sorani", "Arabic", numeral="Latin")
# stemmer = Stem("Sorani", "Arabic")
# from klpt.tokenize import Tokenize
# tokenizer_ckb = Tokenize("Sorani", "Arabic")
# print(tokenizer_ckb.word_tokenize("کرایەوەفێستیڤاڵەکە"))
# print("کرایەوەفێستیڤاڵەکە"[6])
# print(ord("کرایەوەفێستیڤاڵەکە"[6]))
# print(ord("ە"))
# print(stemmer.stem("لەبەسەرکردنەوەماندا"))
# print(stemmer.analyze("سوتان"))

#
# database ="Knn-new-db";
# table = "tbl_KS_BabetiLekchu";
# field_index = 2;
# field_name = 2;
# update = False;

# KNN_Preprocessing.getColoumns([0, 1, 2], True)
# dbdata.cleaning(database,table,field_index,field_name,update)
# preproccessing.process()

from temp_py import stemming
from temp_py import dictAnalayze
print(stemming.stem("بەتەریقکردنەوەوە"))
print(dictAnalayze.pos_tag('ڕاکردن'))
# import word_classifier
# word_classifier.tokenize("yell")