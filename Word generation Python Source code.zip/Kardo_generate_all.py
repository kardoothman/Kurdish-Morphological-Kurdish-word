
saveit  = 1
# print("--> sada sada")
# import generate_sada as sada

# sada.generate_rabrdui_sada("pn"," and id not in (select distinct id_vbgs from generated_words where id_vbgs=vbgs.id and tense='ڕابردووی سادە')", saveit)
# print("--> sada tawaw")
# sada.generate_rabrdui_tawaw("pn", " and id not in (select distinct id_vbgs from generated_words where id_vbgs=vbgs.id and tense='ڕابردووی تەواو')", saveit)
# print("--> sada krdary nziki dananai")
# sada.generate_rabrdui_krdary_nziki_dananee("pn"," and id not in (select distinct id_vbgs from generated_words where id_vbgs=vbgs.id and tense='ڕابردووی کرداری نزیکی دانانی')", saveit)
# print("--> sada krdary tawawe danani")
# sada.generate_rabrdui_krdary_tawawe_dananee("pn"," and id not in (select distinct id_vbgs from generated_words where id_vbgs=vbgs.id and tense='ڕابردووی کرداری تەواوی دانانی')", saveit)
# print("--> sada krdary bardawami danani ")
# sada.generate_rabrdui_krdary_bardawami_dananee("pn", " and id not in (select distinct id_vbgs from generated_words where id_vbgs=vbgs.id and tense='ڕابردووی کرداری بەردەوامی دانانی')", saveit)
# print("--> sada krdary duri danani")
# sada.generate_rabrdui_krdary_dur_dananee("pn", " and id not in (select distinct id_vbgs from generated_words where id_vbgs=vbgs.id and tense='ڕابردووی کرداری دووری دانانی')", saveit)
# print("--> sada bkar nadyar")
# sada.generate_rabrdui_bkar_nadyar("pn", " and id not in (select distinct id_vbgs from generated_words where id_vbgs=vbgs.id and tense='ڕابردووی بکەر نادیار')", saveit)
# print("--> sada All")
# sada.rabrdui_sada("pn", " and id not in (select distinct id_vbgs from generated_words where id_vbgs=vbgs.id and tense='ڕابردووی سادە')", saveit)
#
#
# darezhraw
# import generate_darezhraw as darezhraw

# print("--> darezhraw sada")
# darezhraw.rabrdui_sada("pn", " and id not in (select distinct id_vbgs from generated_words where id_vbgs=vbgs.id and tense='ڕابردووی سادە')", saveit)
# print("-->darezhraw bardawam")
# darezhraw.rabrdui_bardawam("pn", " and id not in (select distinct id_vbgs from generated_words where id_vbgs=vbgs.id and tense='ڕابردووی بەردەوام')", saveit)
# print("-->darezhraw dur")
# darezhraw.rabrdui_dur("pn", " and id not in (select distinct id_vbgs from generated_words where id_vbgs=vbgs.id and tense='ڕابردووی دوور')", saveit)
# print("-->darezhraw nziki danani")
# darezhraw.rabrdui_nzik_danani("pn", " and id not in (select distinct id_vbgs from generated_words where id_vbgs=vbgs.id and tense='ڕابردووی نزیکی دانانی')", saveit)
# print("-->darezhraw bardawami danani")
# darezhraw.rabrdui_bardawami_danani("pn", " and id not in (select distinct id_vbgs from generated_words where id_vbgs=vbgs.id and tense='ڕابردووی بەردەوامی دانانی')", saveit)
# print("-->darezhraw duri danani")
# darezhraw.rabrdui_duri_danani("pn", " and id not in (select distinct id_vbgs from generated_words where id_vbgs=vbgs.id and tense='ڕابردووی دووری دانانی')", saveit)
# print("-->darezhraw bkarnadyar")
# darezhraw.rabrdui_bkarnadyar("pn", " and id not in (select distinct id_vbgs from generated_words where id_vbgs=vbgs.id and tense='ڕابردووی بکەر نادیار')", saveit)
# lekdraw

# print("--> lekdraw sada")
import generate_lekdraw as lekdraw

# lekdraw.rabrdui_sada("pn", " and id not in (select distinct id_vbgs from generated_words where id_vbgs=vbgs.id and tense='ڕابردووی سادە')", saveit)
# print("--> lekdraw bardawam")
# lekdraw.rabrdui_bardawam("pn", " and id not in (select distinct id_vbgs from generated_words where id_vbgs=vbgs.id and tense='ڕابردووی بەردەوام')", saveit)
# print("--> lekdraw dur")
# lekdraw.rabrdui_dur("pn", " and id not in (select distinct id_vbgs from generated_words where id_vbgs=vbgs.id and tense='ڕابردووی دوور')", saveit)
# print("--> lekdraw bardawami danani")
# lekdraw.rabrdui_bardawami_danani("pn", " and id not in (select distinct id_vbgs from generated_words where id_vbgs=vbgs.id and tense='ڕابردووی بەردەوامی دانانی')", saveit)
# print("--> lekdraw duri danani")
# lekdraw.rabrdui_duri_danani("pn", " and id not in (select distinct id_vbgs from generated_words where id_vbgs=vbgs.id and tense='ڕابردووی دووری دانانی')", saveit)
# print("--> lekdraw bkar nadyar ")
# lekdraw.rabrdui_bkarnadyar  ("pn", " and id not in (select distinct id_vbgs from generated_words where id_vbgs=vbgs.id and tense='ڕابردووی بکەر نادیار')", saveit)
# print("--> lekdraw nziki danani")
# lekdraw.rabrdui_nzik_danani("pn", " and id not in (select distinct id_vbgs from generated_words where id_vbgs=vbgs.id and tense='ڕابردووی نزیکی دانانی')", saveit)

print("--> ranabrdu sada darezhraw")
import Ranabrdu as ranabrdu
# ranabrdu.ranabrdui_sada_darezhraw("pn", " and id not in (select distinct id_vbgs from generated_words where id_vbgs=vbgs.id and tense='ڕانەبردووی سادە')", saveit)
# print("--> ranabrdu sada lekdraw")
# ranabrdu.ranabrdui_sada_lekdraw("pn", " and id not in (select distinct id_vbgs from generated_words where id_vbgs=vbgs.id and tense='ڕانەبردووی سادە')", saveit)
print("--> ranabrdu bkar nadyar")
ranabrdu.ranabrdu_bkar_nadyar("pn", " and id not in (select distinct id_vbgs from generated_words where id_vbgs=vbgs.id and tense='ڕانەبردووی بکەر نادیار')", saveit)
# print("--> chawg")
# ranabrdu.chawg("pn", "and id not in (select distinct id_vbgs from generated_words where id_vbgs=vbgs.id and tense='چاوگ')", saveit)
